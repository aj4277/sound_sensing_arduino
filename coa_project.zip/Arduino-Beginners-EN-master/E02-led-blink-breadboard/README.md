## Blinking LED on breadboard
Part of the Bas on Tech Arduino YouTube tutorials - More info at https://arduino-tutorials.net

Subscribe to the Bas on Tech YouTube channel via http://www.youtube.com/c/BasOnTech?sub_confirmation=1

## Circuit
![alt text](./led-blink-breadboard.png "circuit schema")

## Video
[![](http://img.youtube.com/vi/Smfzx4WBb9o/0.jpg)](https://www.youtube.com/watch?v=Smfzx4WBb9o "Blinking LED on breadboard")