# OLED I2C SSD1306 128x64
Part of the Bas on Tech Arduino YouTube tutorials - More info at https://arduino-tutorials.net

Subscribe to the Bas on Tech YouTube channel via http://www.youtube.com/c/BasOnTech?sub_confirmation=1

## The circuit
![alt text](./OLED-I2C-SSD1306-128X64.png "circuit schema")